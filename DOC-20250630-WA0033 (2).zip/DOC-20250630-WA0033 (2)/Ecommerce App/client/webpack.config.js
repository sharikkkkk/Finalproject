// webpack.config.js

import path from "path";

module.exports = {
  // other webpack configurations...

  resolve: {
    fallback: {
      util: false,
    },
  },

  // other webpack configurations...
};
